
#Importing Libraries
"""

from pyspark.sql import SparkSession
import numpy as np
import pyspark.sql.functions as f
from pyspark.sql.window import Window
import sys
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.ml.feature import *
from pyspark.ml import Pipeline
import random

random.seed(10)

"""#Initialising Spark session"""

spark = (SparkSession
           .builder
           .appName("MySpark")
           .getOrCreate())

sc = spark.sparkContext

"""#Reading and Displaying the Data"""

df = spark.read.csv("diabetic_data_valid.csv", inferSchema=True, header=True,nullValue="?")

df.show()

"""#Counting distinct values in each column"""

df.select([f.countDistinct(f.col(c)).alias(c) for c in df.columns]).show()

"""#Changing the datatypes of required variables"""

df = df.withColumn("admission_type_id",df.admission_type_id.cast("String"))
df = df.withColumn("discharge_disposition_id",df.discharge_disposition_id.cast("String"))
df = df.withColumn("admission_source_id",df.admission_source_id.cast("String"))

"""#Separating numeric, categorical and target variables"""

num_variables = df.columns[:6]
cat_variables = df.columns[6:12] + df.columns[15:-2]
target = df.columns[-1]
#cat_variables

"""#Outlier Treatment on Numeric Variables"""

for variable in num_variables:
    q1, q2, q3 = df.select(f.percentile_approx(variable, [0.25, 0.5, 0.75], 1000000).alias("quantiles")).collect()[0]["quantiles"]
    IQR = q3 - q1
    lower_value = q1 - 1.5 * IQR
    upper_value = q3 + 1.5 * IQR
    df = df.withColumn(variable,
                       f.when(f.col(variable) < lower_value,
                              lower_value
                              ).when(f.col(variable) > upper_value,
                                     upper_value
                                     ).otherwise(f.col(variable))
                        )

"""#Defining stages for model data preparation"""

stages = []

for variable in cat_variables:

    # Index Categorical variable
    indexer = StringIndexer(inputCol=variable, outputCol=variable + "_index")
    
    # One Hot Encode Categorical variable
    encoder = OneHotEncoder(inputCols=[indexer.getOutputCol()],
                                     outputCols=[variable + "_OHE_vec"])
    # Append Pipeline Stages
    stages += [indexer, encoder]



# Scale Feature: Select the Features to Scale using helper 'select_features_to_scale' function above and Standardize 
assembler_num = VectorAssembler(inputCols=num_variables, outputCol="num_variables")
scaler_num = StandardScaler(inputCol="num_variables", outputCol="scaled_num_variables")
stages += [assembler_num,scaler_num]


# Assemble or Concat the Categorical Features Features
assembler_cat = [variable + "_OHE_vec" for variable in cat_variables]

assembler = VectorAssembler(inputCols=assembler_cat, outputCol="assembler_cat") 

stages += [assembler]

# Assemble Final Training Data of Scaled, Numeric, and Categorical Engineered Features
assembler_final = VectorAssembler(inputCols=["assembler_cat","scaled_num_variables"], outputCol="variables")

stages += [assembler_final]

# Index Target Variable
target_str_index =  StringIndexer(inputCol=target, outputCol="target")

stages += [target_str_index]

stages

# Set Pipeline
pipeline = Pipeline(stages=stages)

# Fit Pipeline to Data
pipeline_model = pipeline.fit(df)

# Transform Data using Fitted Pipeline
transf_df = pipeline_model.transform(df)

transf_df.show()

"""#Keeping the columns only with the prepared data"""

model_df = transf_df[["variables","target"]]

"""#Spliting data into train and test"""

# Split Data into Train / Test Sets
train_data, test_data = model_df.randomSplit([.7, .3],seed=1234)

train_rdd = train_data.rdd

test_rdd = test_data.rdd
n = test_rdd.count()

"""#Setting hyper-parameters"""

m = train_rdd.count()
beta = sc.broadcast(np.array([random.random() for _ in range(103)]))
alpha = 0.1
lambda_ = 0.1

beta.value

"""#Defining functions for Training the model"""

def l_beta(x):
    x_ = np.insert(x["variables"].toArray(),0,1.0)
    beta_x = np.dot(x_,beta.value)
    sig = 1/(1 + np.exp(-beta_x))
    log1 = np.log(sig)
    log2 = np.log(1 - sig)
    y = x["target"]
    loss = y*log1 + (1-y)*log2
    return -loss

def grad(x):
    x_ = np.insert(x["variables"].toArray(),0,1.0)
    beta_x = np.dot(x_,beta.value)
    sig = 1/(1 + np.exp(-beta_x))
    y = x["target"]
    y_h = sig - y
    return x_ * y_h

"""#Model Training """

#beta_x = X.map(betaT_x)
#h_x = beta_x.map(sigmoid)
#log_h_x = h_x.map(log)
for i in range(50):
    L = train_rdd.map(l_beta)
    train_loss = (L.reduce(lambda x,y: x+y) + lambda_ * np.dot(beta.value[1:],beta.value[1:])/2)/m
    L_test = test_rdd.map(l_beta)
    test_loss = (L.reduce(lambda x,y: x+y))/n
    print("Iteration",i+1," Train_Loss ->",train_loss," Test_loss ->",test_loss)
    del_beta =  train_rdd.map(grad)
    d_beta = del_beta.reduce(lambda x,y: x+y)
    beta = sc.broadcast(beta.value - alpha *(d_beta + lambda_ * np.insert(beta.value[1:],0,0)) / m)
    #print(beta.value[0:5])

"""#Prediction and Test Results """

def metric_cal(x):
    x_ = np.insert(x["variables"].toArray(),0,1.0)
    beta_x = np.dot(x_,beta.value)
    sig = 1/(1 + np.exp(-beta_x))
    y = x["target"]
    y_hat = 1 if sig >= cuttoff.value else 0
    acc = 1 if y == y_hat else 0
    pre_num = 1 if y == y_hat and y_hat == 1 else 0
    pre_denom = 1 if y_hat == 1 else 0
    rec_num = 1 if y == y_hat and y == 1 else 0
    rec_denom = 1 if y == 1 else 0
    return np.array([acc, pre_num, pre_denom, rec_num, rec_denom])

cuttoff = sc.broadcast(0.5)
metrics = test_rdd.map(metric_cal)
cal_metrcis = metrics.reduce(lambda x,y: x+y)
Acc = float(cal_metrcis[0]/n )
Precision = float(cal_metrcis[1]/cal_metrcis[2] )
Recall = float(cal_metrcis[3]/cal_metrcis[4])
F1 = (2 * Precision * Recall)/(Precision + Recall)
print("Cutoff -> {:.2f} Acc -> {:.2f} Precision -> {:.2f} Recall -> {:.2f} F1 -> {:.2f}".format(cuttoff.value,Acc, Precision, Recall,F1))

