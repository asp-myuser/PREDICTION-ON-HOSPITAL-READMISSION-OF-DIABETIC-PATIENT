
#Importing Libraries
"""

from pyspark.sql import SparkSession
import numpy as np
import pyspark.sql.functions as f
from pyspark.sql.window import Window
import sys
import pandas as pd
import matplotlib.pyplot as plt

"""#Initialising Spark session"""

spark = (SparkSession
           .builder
           .appName("MySpark")
           .getOrCreate())

sc = spark.sparkContext

"""#Reading and Displaying the Data"""

df = spark.read.csv("diabetic_data.csv", inferSchema=True, header=True,nullValue="?")

df.show()

"""#Counting Total Number of patients and datatypes of each column"""

total_rows = df.count()
print("There are ",total_rows," rows in our data.")

df.dtypes

"""#Checking whether data is unique on some key"""

patients = df[["patient_nbr"]].groupBy(["patient_nbr"]).count()

patients.columns

patients[patients["count"]>1].orderBy(["count"], ascending = False).show(150)



df[["encounter_id","patient_nbr"]].distinct().count()#.groupBy(["encounter_id","patient_nbr"]).count()

"""#Basic statistics of the data"""

info = df.describe()

info.show()

info.columns[3:]

"""#Removing Columns with high missing values"""

row = info[info.columns[3:]].collect()[0].asDict()

row.items()

counts = sc.parallelize(list(row.items()))

counts.collect()

thresh = 0.9

valid_count_cols = counts.filter(lambda x: (float(x[1])/total_rows)>thresh)

valid_cols = valid_count_cols.map(lambda x: x[0]).collect()

df_valid_cols = df[valid_cols]

df_valid_cols.show()

#df_valid_cols.dtypes

num_variables = [column[0]  for column in df_valid_cols.dtypes if column[1] == 'int']
num_variables = num_variables[3:]
num_variables

cat_variables = [column[0]  for column in df_valid_cols.dtypes if column[0] not in num_variables]
cat_variables



"""#Checking count of Missing Values in categorical variables"""

df_valid_cols.select([f.count(f.when(f.col(c).isNull(),c)).alias(c) for c in cat_variables]).show()

"""#Replacing the missing values"""

total_rows = df_valid_cols.count()
for variable in cat_variables:
    null_count = df_valid_cols.select([f.count(f.when(f.col(variable).isNull(),variable)).alias(variable) ])
    null_count = null_count.collect()[0][variable]
    if null_count == 0 :
        continue
    if null_count > total_rows/100:
        df_valid_cols = df_valid_cols.withColumn(variable,f.when(f.col(variable).isNull(),"OTHERS").otherwise(f.col(variable)))
    else:
        col_cnt = df_valid_cols.groupby(variable).count().orderBy("count", ascending = False)
        mode = col_cnt.collect()[0][variable]
        df_valid_cols = df_valid_cols.withColumn(variable,f.when(f.col(variable).isNull(),mode).otherwise(f.col(variable)))

df_valid_cols.select([f.count(f.when(f.col(c).isNull(),c)).alias(c) for c in cat_variables]).show()



"""#Selecting categorical variables which do not have low variance """

cat_variables_valid = []
for variable in cat_variables:
    col_cnt = df_valid_cols.groupby(variable).count().orderBy("count", ascending = False)
    col_cnt_per = col_cnt.withColumn('cnt_per', f.col('count')/f.sum(col_cnt["count"]).over(Window.partitionBy())*100)
    #col_cnt_per.show()
    col_cnt_per_cumulative = col_cnt_per.withColumn('cnt_per_cumulative', f.sum(col_cnt_per["cnt_per"]).over(Window.partitionBy().orderBy().rowsBetween(-sys.maxsize, 0)))
    col_cnt_per_cumulative.show()
    value = list(col_cnt_per_cumulative.select("cnt_per_cumulative").collect()[0].asDict().values())[0]
    if value <= 99.0:
        cat_variables_valid.append(variable)

print(cat_variables_valid)
print(len(cat_variables_valid))



"""#Checking count of Missing Values in Numeric variables"""

df_valid_cols.select([f.count(f.when(f.col(c).isNull(),c)).alias(c) for c in num_variables]).show()





"""#Visualizing data for Numerical Variables"""

df_pandas = df_valid_cols.withColumn("readmitted_num",f.when(f.col("readmitted") == "NO",0).otherwise(1)).toPandas()
#df_pandas

df_pandas[num_variables + ["readmitted_num"]].corr().style.background_gradient(cmap='coolwarm',vmin = -1).set_precision(2)
#plt.show()

plt.figure(figsize=(16,16))

for i in range(8):
    #Plot 1

    plt.subplot(4,2,i+1)
    plt.title(num_variables[i])
    n, x, _ = plt.hist(df_pandas[num_variables[i]])
    #print(x,n)
    plt.plot([(x[i]+x[i+1])/2 for i in range(len(x)-1)],n)
    #plt.show()

plt.figure(figsize=(16,16))

for i in range(8):
    #Plot 1

    plt.subplot(4,2,i+1)
    plt.title(num_variables[i])
    plt.boxplot(df_pandas[num_variables[i]])

for variable in num_variables:
    col_cnt = df_valid_cols.groupby(variable).count().orderBy("count", ascending = False)
    col_cnt_per = col_cnt.withColumn('cnt_per', f.col('count')/f.sum(col_cnt["count"]).over(Window.partitionBy())*100)
    #col_cnt_per.show()
    col_cnt_per_cumulative = col_cnt_per.withColumn('cnt_per_cumulative', f.sum(col_cnt_per["cnt_per"]).over(Window.partitionBy().orderBy().rowsBetween(-sys.maxsize, 0)))
    col_cnt_per_cumulative.show(40)

num_variables_valid = ['time_in_hospital',
 'num_lab_procedures',
 'num_procedures',
 'num_medications',
 'number_inpatient',
 'number_diagnoses']





"""#Selecting valid columns and saving the dataframe"""

df_valid = df_valid_cols[num_variables_valid + cat_variables_valid].withColumnRenamed("readmitted","readmitted_multinomial")
df_valid.show()

df_valid = df_valid.withColumn("readmitted",f.when(df_valid["readmitted_multinomial"] == "NO", "NO").otherwise("YES"))

df_valid.show()

#df_valid.write.format('com.databricks.spark.csv').save("diabetic_data_valid")

"""#Saving the Dataframe into CSV"""

df_valid.toPandas().to_csv('diabetic_data_valid.csv',index=False)

