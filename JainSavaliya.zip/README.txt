
This code can be executed by 2 methods Either by Jupyter Notebook/gooleCollab or on terminal

To Run Jupyter Notebook:

- Use Anconda/GoogleCollab

To Run src Files:

- python hospital_readmission_project_data_cleaning_and_eda.py
- python hospital_readmission_project_logistic_regression.py


Note:-

- The source code or the python notebook, and the diabetic_data.csv should be in the same folder